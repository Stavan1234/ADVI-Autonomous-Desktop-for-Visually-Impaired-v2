from __future__ import annotations

from dataclasses import dataclass, field

from ..io.output import AdviResponse
from ..memory.retriever import MemoryRetriever
from ..memory.session import SessionBuffer
from ..memory.short_term import ShortTermMemory
from ..providers import LLMProvider


@dataclass
class ConversationEngine:
    provider: LLMProvider
    memory: ShortTermMemory = field(
        default_factory=ShortTermMemory
    )
    session_buffer: SessionBuffer = field(
        default_factory=SessionBuffer
    )
    retriever: MemoryRetriever | None = None
    previous_session_context: str | None = None

    def respond(
        self,
        user_input: str,
    ) -> AdviResponse:
        text = user_input.strip()

        if not text:
            return AdviResponse("")

        evicted = self.memory.add(
            "user",
            text,
        )

        self.session_buffer.add(evicted)

        messages = self.memory.get_messages()
        request_messages = list(messages)

        system_parts: list[str] = []

        if self.retriever is not None:
            retrieved = self.retriever.search(
                text,
                limit=3,
            )

            relevant = self._filter_relevant(
                retrieved
            )

            if relevant:
                memory_context = "\n".join(
                    f"- {item.memory.statement}"
                    for item in relevant
                )

                system_parts.append(
                    "Relevant long-term memory:\n"
                    + memory_context
                )

        if self.previous_session_context:
            system_parts.append(
                "Recent session context:\n"
                + self.previous_session_context
            )

        if system_parts:
            request_messages.insert(
                0,
                {
                    "role": "system",
                    "content": (
                        "You are ADVI, an Autonomous Desktop "
                        "for the Visually Impaired.\n\n"
                        "Answer clearly, naturally, and "
                        "appropriately for speech.\n\n"
                        + "\n\n".join(system_parts)
                        + "\n\n"
                        "Use this context only when relevant."
                    ),
                },
            )

        result = self.provider.chat(
            request_messages
        )

        evicted = self.memory.add(
            "assistant",
            result.text,
        )

        self.session_buffer.add(evicted)

        return AdviResponse(result.text)

    def get_session_buffer(
        self,
    ) -> list[dict[str, str]]:
        return [
            message.copy()
            for message in self.session_buffer.messages
        ] + self.memory.get_messages()

    @staticmethod
    def _filter_relevant(
        memories,
    ):
        return [
            item
            for item in memories
            if item.score >= 0.40
        ][:3]