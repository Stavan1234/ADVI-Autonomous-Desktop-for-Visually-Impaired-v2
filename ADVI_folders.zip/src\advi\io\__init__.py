"""Input/output adapters."""
