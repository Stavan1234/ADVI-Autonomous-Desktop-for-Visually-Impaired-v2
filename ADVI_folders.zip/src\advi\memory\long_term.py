# from aiohttp import client_middleware_digest_auth
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import sqlite3
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .consolidator import ConsolidationResult


@dataclass(frozen=True)
class Memory:
    id: int
    category: str
    key: str
    value: str
    statement: str
    confidence: float
    created_at: str
    updated_at: str


class LongTermMemory:
    """Persistent memory backed by SQLite."""

    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            self.database_path
        )
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value TEXT NOT NULL,
                    statement TEXT NOT NULL,
                    confidence REAL NOT NULL DEFAULT 0.8,
                    created_at TEXT NOT NULL
                        DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL
                        DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(category, key)
                )
                """
            )

            columns = {
                row["name"]
                for row in connection.execute(
                    "PRAGMA table_info(memories)"
                ).fetchall()
            }

            if "statement" not in columns:
                connection.execute(
                    """
                    ALTER TABLE memories
                    ADD COLUMN statement TEXT
                    """
                )

                connection.execute(
                    """
                    UPDATE memories
                    SET statement =
                        CASE
                            WHEN category = 'user'
                                THEN 'The user has '
                                     || key
                                     || ': '
                                     || value
                            ELSE
                                category
                                || ': '
                                || key
                                || ': '
                                || value
                        END
                    WHERE statement IS NULL
                    """
                )

            if "confidence" not in columns:
                connection.execute(
                    """
                    ALTER TABLE memories
                    ADD COLUMN confidence REAL
                        NOT NULL DEFAULT 0.8
                    """
                )

            connection.execute(
                """
                CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
                USING fts5(
                    category,
                    key,
                    value,
                    statement,
                    content='memories',
                    content_rowid='id'
                )
                """
            )

            connection.execute(
                """
                CREATE TRIGGER IF NOT EXISTS memories_ai
                AFTER INSERT ON memories
                BEGIN
                    INSERT INTO memories_fts(
                        rowid,
                        category,
                        key,
                        value,
                        statement
                    )
                    VALUES (
                        new.id,
                        new.category,
                        new.key,
                        new.value,
                        new.statement
                    );
                END
                """
            )

            connection.execute(
                """
                CREATE TRIGGER IF NOT EXISTS memories_ad
                AFTER DELETE ON memories
                BEGIN
                    INSERT INTO memories_fts(
                        memories_fts,
                        rowid,
                        category,
                        key,
                        value,
                        statement
                    )
                    VALUES (
                        'delete',
                        old.id,
                        old.category,
                        old.key,
                        old.value,
                        old.statement
                    );
                END
                """
            )

            connection.execute(
                """
                CREATE TRIGGER IF NOT EXISTS memories_au
                AFTER UPDATE ON memories
                BEGIN
                    INSERT INTO memories_fts(
                        memories_fts,
                        rowid,
                        category,
                        key,
                        value,
                        statement
                    )
                    VALUES (
                        'delete',
                        old.id,
                        old.category,
                        old.key,
                        old.value,
                        old.statement
                    );

                    INSERT INTO memories_fts(
                        rowid,
                        category,
                        key,
                        value,
                        statement
                    )
                    VALUES (
                        new.id,
                        new.category,
                        new.key,
                        new.value,
                        new.statement
                    );
                END
                """
            )

            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_at TEXT NOT NULL
                        DEFAULT CURRENT_TIMESTAMP,
                    ended_at TEXT,
                    summary TEXT
                )
                """
            )

            connection.execute(
                """
                INSERT INTO memories_fts(memories_fts)
                VALUES ('rebuild')
                """
            )

    def all(self) -> list[Memory]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT
                    id,
                    category,
                    key,
                    value,
                    statement,
                    confidence,
                    created_at,
                    updated_at
                FROM memories
                ORDER BY updated_at DESC
                """
            ).fetchall()

        return [
            Memory(**dict(row))
            for row in rows
        ]

    def remember(
        self,
        category: str,
        key: str,
        value: str,
        statement: str | None = None,
        confidence: float = 0.8,
    ) -> None:
        category = category.strip()
        key = key.strip()
        value = value.strip()

        if statement is None:
            statement = (
                f"The user has {key}: {value}."
            )

        statement = statement.strip()

        if (
            not category
            or not key
            or not value
            or not statement
        ):
            return

        confidence = max(
            0.0,
            min(1.0, float(confidence)),
        )

        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO memories (
                    category,
                    key,
                    value,
                    statement,
                    confidence
                )
                VALUES (?, ?, ?, ?, ?)

                ON CONFLICT(category, key)
                DO UPDATE SET
                    value = excluded.value,
                    statement = excluded.statement,
                    confidence = excluded.confidence,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (
                    category,
                    key,
                    value,
                    statement,
                    confidence,
                ),
            )

    def recent_sessions(
        self,
        limit: int = 3,
    ) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT
                    id,
                    started_at,
                    ended_at,
                    summary
                FROM sessions
                WHERE summary IS NOT NULL
                AND summary != ''
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()

        return [dict(row) for row in rows]        

    def recall(
        self,
        category: str,
        key: str,
    ) -> Memory | None:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT
                    id,
                    category,
                    key,
                    value,
                    statement,
                    confidence,
                    created_at,
                    updated_at
                FROM memories
                WHERE category = ?
                  AND key = ?
                """,
                (category, key),
            ).fetchone()

        if row is None:
            return None

        return Memory(**dict(row))

    def search(
        self,
        query: str,
        limit: int = 5,
    ) -> list[Memory]:
        query = query.strip()

        if not query:
            return []

        terms = [
            term.strip('"')
            for term in query.split()
            if len(term) >= 2
        ]

        if not terms:
            return []

        fts_query = " OR ".join(
            f'"{term.replace(chr(34), "")}"'
            for term in terms
        )

        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT
                    rowid
                FROM memories_fts
                WHERE memories_fts MATCH ?
                ORDER BY rank
                LIMIT ?
                """,
                (fts_query, limit),
            ).fetchall()

        results: list[Memory] = []

        for row in rows:
            with self._connect() as connection:
                memory_row = connection.execute(
                    """
                    SELECT
                        id,
                        category,
                        key,
                        value,
                        statement,
                        confidence,
                        created_at,
                        updated_at
                    FROM memories
                    WHERE id = ?
                    """,
                    (row["rowid"],),
                ).fetchone()

            if memory_row is not None:
                results.append(
                    Memory(**dict(memory_row))
                )

        return results

    def forget(
        self,
        category: str,
        key: str,
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                DELETE FROM memories
                WHERE category = ?
                  AND key = ?
                """,
                (category, key),
            )

    def clear(self) -> None:
        with self._connect() as connection:
            connection.execute(
                "DELETE FROM memories"
            )

    def start_session(self) -> int:
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO sessions DEFAULT VALUES"
            )
            return int(cursor.lastrowid)

    def end_session(
        self,
        session_id: int,
        summary: str | None = None,
    ) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                UPDATE sessions
                SET ended_at = CURRENT_TIMESTAMP,
                    summary = ?
                WHERE id = ?
                """,
                (summary, session_id),
            )

    def save_consolidation(
        self,
        result: ConsolidationResult,
    ) -> None:
        for memory in result.memories:
            self.remember(
                category=memory.category,
                key=memory.key,
                value=memory.value,
                statement=memory.statement,
                confidence=memory.confidence,
            )

    def latest_session(self) -> dict | None:
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT
                    id,
                    started_at,
                    ended_at,
                    summary
                FROM sessions
                ORDER BY id DESC
                LIMIT 1
                """
            ).fetchone()

        return dict(row) if row else None