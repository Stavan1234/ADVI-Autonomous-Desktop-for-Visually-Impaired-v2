"""Future executable tool adapters."""
